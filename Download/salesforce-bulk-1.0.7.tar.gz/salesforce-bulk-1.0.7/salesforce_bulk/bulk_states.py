ABORTED = 'Aborted'
FAILED = 'Failed'
NOT_PROCESSED = 'Not Processed'
COMPLETED = 'Completed'

ERROR_STATES = (
    ABORTED,
    FAILED,
    NOT_PROCESSED,
)
