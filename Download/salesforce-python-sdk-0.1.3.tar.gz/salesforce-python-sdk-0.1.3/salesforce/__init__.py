from salesforce.api import Salesforce
from salesforce.exception import RequestFailed